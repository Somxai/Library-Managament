package com.bookstore.com.controller.authorController;

import com.bookstore.com.dto.authorDto.AuthorDto;
import com.bookstore.com.services.authorService.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;



@RestController
@RequestMapping(path = "/authors")
public class AuthorController {


    @Autowired
    AuthorService authorService;


        @GetMapping( path = "/fetchAll")
        public List<AuthorDto> fetchAllBook(@RequestParam(value = "pageNo",defaultValue = "0") Integer pageNo,
                                            @RequestParam(value = "pageSize", defaultValue = "5") Integer pageSize,
                                            @RequestParam(value = "sort",defaultValue = "firstName") String sort){

            return authorService.fetchAll(pageNo,pageSize,sort);
        }


    @GetMapping(path = "/fetchById/{id}")
    public ResponseEntity<AuthorDto> fetchById(@PathVariable Long id){
        AuthorDto authorDto = authorService.fetchById(id);
        return ResponseEntity.ok(authorDto);
    }






}






