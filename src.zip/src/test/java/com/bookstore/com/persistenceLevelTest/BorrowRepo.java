package com.bookstore.com.persistenceLevelTest;

public class BorrowRepo {
}
