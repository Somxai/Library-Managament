package com.bookstore.com.dao;


import com.bookstore.com.domain.lateReturn.LateReturn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LateReturnRepository extends JpaRepository<LateReturn, Long> {
}