package com.bookstore.com.services.authorService;

import com.bookstore.com.ConfigPackage.ModelMappers;
import com.bookstore.com.dao.AuthorRepository;
import com.bookstore.com.domain.author.Author;
import com.bookstore.com.dto.authorDto.AuthorDto;
import com.bookstore.com.exception.authorException.NoSuchAuthorExistException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class AuthorService {

    private static final Logger logger = LoggerFactory.getLogger(AuthorService.class);


    ModelMappers modelMapper;

    AuthorRepository authorRepository;
    @Autowired
    public AuthorService(@Lazy AuthorRepository authorRepository, ModelMappers modelMappers) {
        this.authorRepository = authorRepository;
        this.modelMapper = modelMappers;
    }

    public AuthorDto fetchById(Long id){


            Optional<Author> author = authorRepository.fetchById(id);
            if (author.isEmpty()){
                logger.info("author is not exist");
                throw new NoSuchAuthorExistException("author id "+ id + " is not exist in database");
            }
            try {
                logger.info("start converting.... and show author before convert : " + author.get());
                AuthorDto authorDto = modelMapper.authorToDto(author.get());
                logger.info("after converted DTO: " + authorDto);
                return authorDto;

            }catch (NoSuchAuthorExistException e) {
            logger.error("error happen");
            throw  new NoSuchAuthorExistException("error occur while converting and return "+ e.getMessage());


        }

    }

    @Cacheable(value = "authors")
    public List<AuthorDto> fetchAll(int pageNo,int pageSize,String sort){
        try {
            Pageable pageable = PageRequest.of(pageNo,pageSize, Sort.by(sort));
            Page<Author> authors = authorRepository.findAll(pageable);
            logger.info("Starting to map author to dto" );
            List<AuthorDto> authorDtos = authors.stream().map(author ->modelMapper.authorToDto(author)).
                    collect(Collectors.toList());
            for (AuthorDto authorDto: authorDtos){
                logger.info("author : " + authorDto);

            }
            logger.info("after  mapped author to " + authorDtos.size());

            return authorDtos;

        }catch (Exception e){
            logger.error(e.getMessage());
            return null;
        }

    }

    @Transactional
    public Author fetchByName(String name){
        try {
            Author author = authorRepository.fetchByName(name);
            return author;
        }catch (Exception e){
            logger.error("fetch author error" , e);
            return null;

        }

    }

    @Transactional
    public Author createAuthor(AuthorDto authorDto){
        try {
            Author author = modelMapper.DtoToAuthor(authorDto);
            return authorRepository.save(author);

        }catch (Exception e){
            logger.error(e.getMessage());
            return null;
        }
    }

    }





