package com.bookstore.com.dto.borrowDto;

import com.bookstore.com.dto.bookDto.BookDto;
import com.bookstore.com.dto.lateReturnDto.LateReturnDto;
import com.bookstore.com.dto.studentDto.StudentDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Date;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BorrowDto {

    private Long borrow_id;


    private Date date_borrow;

    private Date date_return;



    private BookDto books;


    private StudentDto students;


    private LateReturnDto lateReturn;


    @Override
    public String toString() {
        return "BorrowDto{" +
                "borrow_id=" + borrow_id +
                ", date_borrow=" + date_borrow +
                ", date_return=" + date_return +
                ", books=" + books +
                ", students=" + students +
                ", lateReturn=" + lateReturn +
                '}';
    }
}
