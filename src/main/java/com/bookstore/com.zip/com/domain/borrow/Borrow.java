package com.bookstore.com.domain.borrow;

import com.bookstore.com.domain.book.Book;
import com.bookstore.com.domain.lateReturn.LateReturn;
import com.bookstore.com.domain.student.Student;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Date;
import java.util.Objects;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "borrow")
public class Borrow {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "borrow_id", nullable = false)
    private Long borrow_id;

    @Column(name = "date_borrow")
    private Date date_borrow;

    @Column(name = "date_return")
    private Date date_return;


    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "id")
    @JsonBackReference
    private Book books;


    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "std_id")
    private Student students;

    @OneToOne(cascade = CascadeType.ALL,orphanRemoval = true, fetch = FetchType.LAZY)
    @JoinColumn(name = "lateReturn_id")
    private LateReturn lateReturn;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Borrow borrow = (Borrow) o;
        return Objects.equals(borrow_id, borrow.borrow_id) && Objects.equals(date_borrow, borrow.date_borrow) && Objects.equals(date_return, borrow.date_return);
    }

    @Override
    public int hashCode() {
        return Objects.hash(borrow_id, date_borrow, date_return);
    }

    @Override
    public String toString() {
        return "Borrow{" +
                "borrow_id=" + borrow_id +
                ", date_borrow=" + date_borrow +
                ", date_return=" + date_return +
                '}';
    }
}