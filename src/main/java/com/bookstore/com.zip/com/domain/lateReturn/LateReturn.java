package com.bookstore.com.domain.lateReturn;

import com.bookstore.com.domain.book.Book;
import com.bookstore.com.domain.borrow.Borrow;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;
import java.util.Objects;

@Getter
@Setter
@Entity
@Table(name = "late_return")
public class LateReturn {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "lateReturn_id", nullable = false)
    private Long lateReturn_id;

    @Column(name = "dueDate")
    private Date dueDate;

    @Column(name = "feeCharge")
    private Double feeCharge;


    @OneToOne(mappedBy = "lateReturn",cascade = CascadeType.ALL)
    private Borrow borrowReturn;


    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "id")
    @JsonBackReference
    private Book bookLateReturn;








    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LateReturn that = (LateReturn) o;
        return Objects.equals(lateReturn_id, that.lateReturn_id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(lateReturn_id);
    }


    @Override
    public String toString() {
        return "LateReturn{" +
                "lateReturn_id=" + lateReturn_id +
                ", dueDate=" + dueDate +
                ", feeCharge=" + feeCharge +
                '}';
    }
}